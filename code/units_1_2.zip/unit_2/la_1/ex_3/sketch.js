function setup(){
	createCanvas(600, 240);
}

function draw() {
  ellipse(mouseX, mouseY, 10, 10);
}