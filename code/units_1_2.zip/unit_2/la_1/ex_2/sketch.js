function setup(){
	createCanvas(600, 240);
}

function draw() {
  background(180); 
  ellipse(mouseX, mouseY, 10, 10);
}