function setup() {
  createCanvas(600, 120);
}

function draw() {
	background(180);
	var y = 70;

  	ellipse(120, y, 60, 60);
  	ellipse(200, y, 60, 60);
  	ellipse(280, y, 60, 60);
  	ellipse(360, y, 60, 60);
  	ellipse(440, y, 60, 60);
}