function setup() {
  createCanvas(600, 120);
}

function draw() {
	background(180);
  	ellipse(width/2, height/2, 60, 60);
}