//Declare variables
var x;
var y;

function setup() {
  createCanvas(600, 120);

  //Initialize variables
  x = random(0, width);
  y = random(0, height/2);
}

function draw() {
  background(20);

  //Face
  fill(255);
  ellipse(x, y, 100, 100);
  
  //Eye 1
  fill(0);
  ellipse(x, y+10, 10, 10);
  
  //Eye 2
  ellipse(x+20, y+10, 10, 10);
  
  //Mouth
    arc(x, y+25, 30, 30, 0, radians(180), PIE);
  
}