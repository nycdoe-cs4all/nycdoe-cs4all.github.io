function setup() {
  createCanvas(600, 120);
}

function draw() {
	background(180);
	ellipse(120, 60, 60, 60);
	ellipse(200, 60, 60, 60);
	ellipse(280, 60, 60, 60);
	ellipse(360, 60, 60, 60);
	ellipse(440, 60, 60, 60);
}