function setup() {
  createCanvas(600, 120);

}

function draw() {
	background(180);

	//Draw the value of the width variable on the screen
 	text(width, 40, 40);

 	//Draw the value of the height variable on the screen
 	text(height, 40, 60);

}