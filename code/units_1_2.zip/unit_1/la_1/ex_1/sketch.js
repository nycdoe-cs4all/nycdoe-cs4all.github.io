
function setup() {
  createCanvas(600, 240);
  
}

function draw(){
	//'background' takes a number between 0 (black) and 255 (white). 
	//Numbers in between are different shades of gray.
	background(180);
	
}