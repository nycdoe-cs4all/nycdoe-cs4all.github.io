
function setup() {
  createCanvas(600, 120);
}

function draw() {
  background(180);
  
  //Draw a point at x=110, and y=80
  point(110, 80);

  //Draw a line from point(300, 20) to (400, 100)
  line(300, 20, 400, 100);
}