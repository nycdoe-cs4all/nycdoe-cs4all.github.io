function setup() {
  createCanvas(600, 120);
}

function draw() {
  background(204);
  rect(40, 40, 400, 60);
  ellipse(335, 50, 50, 50);
}