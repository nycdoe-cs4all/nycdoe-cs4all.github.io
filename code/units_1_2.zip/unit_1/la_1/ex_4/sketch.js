function setup() { 
	createCanvas(600, 120);
}

function draw() { 
	background(100);
	text(mouseX + ", " + mouseY, 20, 20);
}