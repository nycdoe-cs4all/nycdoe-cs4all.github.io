function setup() {
  createCanvas(600, 120);
}

function draw() {
  background(180);
  //Draw a rectangle at x=40, y=40, that is 400 pixels wide and 60 pixels high.
  rect(40, 40, 400, 60);

}