function setup() {
  createCanvas(600, 120);
  noStroke();
}

function draw() {
  background(180);
  ellipse(100, 60, 40, 40);
  ellipse(200, 60, 40, 40);
  ellipse(300, 60, 40, 40);
  ellipse(400, 60, 40, 40);
  ellipse(500, 60, 40, 40);
}